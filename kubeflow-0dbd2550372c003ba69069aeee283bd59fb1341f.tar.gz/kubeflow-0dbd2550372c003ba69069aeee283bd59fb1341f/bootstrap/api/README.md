# API For kfctl

This directory contains a swagger spec for an API for kfctl.

See [API Docs](https://rebilly.github.io/ReDoc/?url=https://raw.githubusercontent.com/kubeflow/kubeflow/master/bootstrap/api/swagger.yaml#tag/KfConfig)