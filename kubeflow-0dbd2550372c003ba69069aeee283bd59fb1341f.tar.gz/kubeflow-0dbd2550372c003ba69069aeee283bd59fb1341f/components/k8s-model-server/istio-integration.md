# Istio integration for TF serving

Please see the official [Istio on
Kubeflow](https://www.kubeflow.org/docs/guides/components/istio/) documentation.
